package version

var (
	// Version shows the last bbolt binary version released.
	Version = "1.4.3"
)
