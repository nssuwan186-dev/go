# go-conventional-commit

golang parser for conventional-commit messages https://www.conventionalcommits.org/
