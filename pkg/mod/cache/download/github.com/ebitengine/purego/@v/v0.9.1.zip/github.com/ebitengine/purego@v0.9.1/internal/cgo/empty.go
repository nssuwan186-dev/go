// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: 2024 The Ebitengine Authors

package cgo

// Empty so that importing this package doesn't cause issue for certain platforms.
