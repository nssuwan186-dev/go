# tuf and tuf-client CLI tools

----------------------------

## Overview

----------------------------

The following CLIs are experimental replacements of the CLI tools provided by the go-tuf package:

* [tuf-client](tuf-client/README.md) - a CLI tool that implements the client workflow specified by The Update Framework (TUF) specification

* [tuf](tuf/README.md) - Not implemented
