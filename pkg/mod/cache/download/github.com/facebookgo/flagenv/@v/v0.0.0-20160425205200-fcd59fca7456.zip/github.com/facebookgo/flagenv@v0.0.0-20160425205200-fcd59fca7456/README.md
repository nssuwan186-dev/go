flagenv [![Build Status](https://secure.travis-ci.org/facebookgo/flagenv.png)](http://travis-ci.org/facebookgo/flagenv)
=======

Documentation: http://godoc.org/github.com/facebookgo/flagenv
