//go:build !unix

package util

type mmapState struct{}
