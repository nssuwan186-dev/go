# Go SQLite Utilities

This folder collects additional SQLite utilities
that help extension writers provide a consistent developer experience.