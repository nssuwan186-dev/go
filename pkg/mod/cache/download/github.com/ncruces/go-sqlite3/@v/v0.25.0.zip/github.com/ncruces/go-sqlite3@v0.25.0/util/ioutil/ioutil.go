// Package ioutil implements I/O utilities.
package ioutil
