// Package x is a collection of experimental features for use within the GitHub CLI and CLI extensions.
//
// Anything contained is subject to change without notice until it is considered stable enough to be promoted.
package x
