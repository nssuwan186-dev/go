// Package color handles experimental GitHub CLI user experiences focused on color rendering concerns such as accessibility and color roles.
//
// Note this is an experimental package where the API is subject to change.
package color
