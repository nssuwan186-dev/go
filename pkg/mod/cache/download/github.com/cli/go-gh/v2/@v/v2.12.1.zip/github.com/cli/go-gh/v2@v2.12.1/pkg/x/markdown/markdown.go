// Package markdown handles experimental GitHub CLI user experiences focused on markdown rendering concerns such as accessibility.
//
// Note this is an experimental package where the API is subject to change.
package markdown
