// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

package internal

const PackageVersion = "0.1.0-beta.2" // x-release-please-version
