// SPDX-FileCopyrightText: Copyright 2015-2025 go-swagger maintainers
// SPDX-License-Identifier: Apache-2.0

// Package strfmt contains custom string formats
//
// TODO: add info on how to define and register a custom format
package strfmt
