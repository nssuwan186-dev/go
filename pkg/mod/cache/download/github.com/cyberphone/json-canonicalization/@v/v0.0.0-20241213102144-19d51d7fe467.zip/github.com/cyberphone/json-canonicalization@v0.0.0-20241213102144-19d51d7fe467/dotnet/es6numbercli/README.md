## Interactive ES6 Compatible JSON Number debugger for .NET
