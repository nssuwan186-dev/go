## JCS (RFC 8785) compatible canonicalizer for .NET

The project **verify-canonicalization** contains the actual test program.
