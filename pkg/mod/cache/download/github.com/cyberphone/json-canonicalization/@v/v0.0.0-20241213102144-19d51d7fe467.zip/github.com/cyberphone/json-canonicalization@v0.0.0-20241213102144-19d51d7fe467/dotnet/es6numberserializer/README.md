## ES6 Compatible JSON Number Serialization for .NET

This project contains a port from Mozilla's JavaScript engine in Java ("Rhino").

The code has been verified using a test file with a 100 million of random and selected values:
https://onedrive.live.com/embed?cid=9341770E0D0D5468&resid=9341770E0D0D5468%21222&authkey=ADOClRsuPv3_pTk

The project **verify-es6numberserialization** contains the actual test program.
