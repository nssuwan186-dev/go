### Node.js canonicalizer + test programs

For running `verify-numbers.js` you need to download a 3Gb+ file with test
data described in the root directory `testdata`.  This file can be stored in
any directory and requires updating the file path in `verify-numbers.js`


```code
$ node verify-canonicalization.js
$ node verify-numbers.js
```
