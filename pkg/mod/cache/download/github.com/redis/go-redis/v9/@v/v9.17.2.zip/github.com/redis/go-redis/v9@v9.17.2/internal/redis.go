package internal

const RedisNull = "<nil>"
