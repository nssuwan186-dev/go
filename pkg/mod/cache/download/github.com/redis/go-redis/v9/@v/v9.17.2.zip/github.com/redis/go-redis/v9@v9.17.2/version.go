package redis

// Version is the current release version.
func Version() string {
	return "9.17.2"
}
