// Package genopenapi provides a code generator for OpenAPI v2.
package genopenapi
