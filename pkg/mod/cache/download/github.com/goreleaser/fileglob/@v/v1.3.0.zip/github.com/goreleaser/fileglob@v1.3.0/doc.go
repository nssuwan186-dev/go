// Package fileglob provides a filesystem glob API.
package fileglob
