#!/bin/sh

echo "$@"

echo "PreUpgrade" > /dev/null
