#!/bin/bash

echo "Verify" > /dev/null
