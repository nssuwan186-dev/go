#!/bin/bash

echo "Ok" > /tmp/pretrans-proof
