package main

func main() {
	println("fake linux binary")
}
