// Package cmd contains the main nfpm cli source code.
package cmd
