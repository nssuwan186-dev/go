#!/bin/sh

test -e /tmp/postinstall-proof
