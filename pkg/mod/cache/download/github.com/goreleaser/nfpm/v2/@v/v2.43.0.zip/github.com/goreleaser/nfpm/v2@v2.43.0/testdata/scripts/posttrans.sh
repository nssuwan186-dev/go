#!/bin/bash

echo "Posttrans" > /dev/null
