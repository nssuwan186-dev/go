#!/bin/sh

echo "Ok" > /tmp/postupgrade-proof
