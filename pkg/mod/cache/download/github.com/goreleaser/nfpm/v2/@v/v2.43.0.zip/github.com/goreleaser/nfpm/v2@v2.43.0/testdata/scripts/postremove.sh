#!/bin/bash

echo "Postremove" > /dev/null
