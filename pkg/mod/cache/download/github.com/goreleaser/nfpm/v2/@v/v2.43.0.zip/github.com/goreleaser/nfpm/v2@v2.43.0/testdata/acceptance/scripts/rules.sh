#!/usr/bin/make -f
#export DH_VERBOSE = 1

%:
	echo "deb rules"
	dh $@
