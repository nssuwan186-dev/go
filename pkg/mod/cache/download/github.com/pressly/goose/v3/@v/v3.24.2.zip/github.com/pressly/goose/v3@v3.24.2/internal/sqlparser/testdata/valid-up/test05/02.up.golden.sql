CREATE TABLE ssh_keys_backup (
    id integer NOT NULL,
    -- insert comment here
    "publicKey" text
    -- insert comment there
);