CREATE TABLE article (
    id text,
            content text);