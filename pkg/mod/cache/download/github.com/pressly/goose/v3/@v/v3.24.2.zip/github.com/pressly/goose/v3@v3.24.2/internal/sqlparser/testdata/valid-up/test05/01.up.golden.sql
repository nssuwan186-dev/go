CREATE TABLE ssh_keys (
    id integer NOT NULL,
    "publicKey" text
-- insert comment there
);