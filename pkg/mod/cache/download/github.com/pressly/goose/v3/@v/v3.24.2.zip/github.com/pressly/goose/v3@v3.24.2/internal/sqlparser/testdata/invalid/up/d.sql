-- +goose Up
SELECT * FROM bar
