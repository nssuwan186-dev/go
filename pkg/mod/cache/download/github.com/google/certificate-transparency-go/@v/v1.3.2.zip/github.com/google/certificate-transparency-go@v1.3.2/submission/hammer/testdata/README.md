precert.der contains DER-encoded pre-certificate signed by testing CA
interim.der contains DER-encoded intermediate testing CA cert