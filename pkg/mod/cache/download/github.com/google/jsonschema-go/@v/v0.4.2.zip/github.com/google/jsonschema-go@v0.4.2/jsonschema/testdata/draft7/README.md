# JSON Schema test suite for draft-07

These files were copied from
https://github.com/json-schema-org/JSON-Schema-Test-Suite/tree/83e866b46c9f9e7082fd51e83a61c5f2145a1ab7/tests/draft7.

The following files were omitted:

The "optional" directory: this package doesn't implement any optional features.
