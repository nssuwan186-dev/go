## Generate docs for `crane`

```go
go run cmd/crane/help/main.go --dir=cmd/crane/doc/
```
