# `google`

[![GoDoc](https://godoc.org/github.com/google/go-containerregistry/pkg/v1/google?status.svg)](https://godoc.org/github.com/google/go-containerregistry/pkg/v1/google)

The `google` package provides:
* Some google-specific authentication methods.
* Some [GCR](gcr.io)-specific listing methods.
