# `daemon`

[![GoDoc](https://godoc.org/github.com/google/go-containerregistry/pkg/v1/daemon?status.svg)](https://godoc.org/github.com/google/go-containerregistry/pkg/v1/daemon)

The `daemon` package enables reading/writing images from/to the docker daemon.

It is not fully fleshed out, but is useful for interoperability, see various issues:

* https://github.com/google/go-containerregistry/issues/205
* https://github.com/google/go-containerregistry/issues/552
* https://github.com/google/go-containerregistry/issues/627
