package util

func StrP(s string) *string {
	return &s
}
