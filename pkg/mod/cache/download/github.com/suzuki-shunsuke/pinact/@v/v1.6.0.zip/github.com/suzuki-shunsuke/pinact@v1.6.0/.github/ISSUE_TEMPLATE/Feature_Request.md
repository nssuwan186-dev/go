---
name: Feature Request
about: If you want to add a feature.
---

## Feature Overview


## Why is the feature needed?

> Please explain the problem you want to solve.


## Example Code

> command and configuration

```console
$ 
```

```yaml

```
