sigstore-protobuf-specs
=======================

Rust language bindings for Sigstore's protobuf specs.

See the [sigstore's protobuf-specs](https://github.com/sigstore/protobuf-specs)
for more information.
