## Service Protos

A mirror of proto defintions from various sigstore services
- `./rekor/v2`: `https://github.com/sigstore/rekor-tiles/api/proto/"rekor/v2/*.proto"`
