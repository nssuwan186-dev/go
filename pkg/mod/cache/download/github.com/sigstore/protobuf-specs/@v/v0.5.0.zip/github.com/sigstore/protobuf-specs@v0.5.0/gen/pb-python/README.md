sigstore-protobuf-specs
=======================

These are the Python language bindings for Sigstore's protobuf specs.

See the [repository's README](https://github.com/sigstore/protobuf-specs)
for more information.
