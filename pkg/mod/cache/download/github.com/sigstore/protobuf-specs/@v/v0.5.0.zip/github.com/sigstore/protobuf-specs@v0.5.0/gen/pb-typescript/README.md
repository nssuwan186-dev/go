# @sigstore/protobuf-specs

TypeScript language bindings for Sigstore's protobuf specs.

See the [repository's README](https://github.com/sigstore/protobuf-specs) for more information.
