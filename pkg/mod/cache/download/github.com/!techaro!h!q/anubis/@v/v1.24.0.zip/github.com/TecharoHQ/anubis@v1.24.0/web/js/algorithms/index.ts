import fast from "./fast";

export default {
  fast: fast,
  slow: fast, // XXX(Xe): slow is deprecated, but keep this around in case anything goes bad
}