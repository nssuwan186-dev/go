package challengetest

import "testing"

func TestNew(t *testing.T) {
	_ = New(t)
}
