# meta policies

Contains policies that exclusively reference policies in _multiple_ other data folders.

Akin to "stances" that the administrator can take, with reference to various topics, such as AI/LLM systems.