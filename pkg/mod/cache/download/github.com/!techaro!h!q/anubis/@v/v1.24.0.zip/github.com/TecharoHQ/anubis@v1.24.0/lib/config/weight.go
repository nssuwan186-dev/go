package config

type Weight struct {
	Adjust int `json:"adjust" yaml:"adjust"`
}
