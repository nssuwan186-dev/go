# thoth-proto
Θώθ what's this?
