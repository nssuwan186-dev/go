# [0.5.0](https://github.com/TecharoHQ/thoth-proto/compare/v0.4.0...v0.5.0) (2025-10-31)


### Features

* analytics API ([c54d056](https://github.com/TecharoHQ/thoth-proto/commit/c54d0560fc47caff7325f932fed5ed7de0082bae))

# [0.4.0](https://github.com/TecharoHQ/thoth-proto/compare/v0.3.0...v0.4.0) (2025-06-09)


### Features

* reputation service ([042d2cf](https://github.com/TecharoHQ/thoth-proto/commit/042d2cf351b5114ebc94e285331771de2feb91a7))

# [0.3.0](https://github.com/TecharoHQ/thoth-proto/compare/v0.2.0...v0.3.0) (2025-05-21)


### Features

* **iptoasn:** asn numbers are uint32 ([eb09ab5](https://github.com/TecharoHQ/thoth-proto/commit/eb09ab58433133c54ec00938d856e3f798cae230))

# [0.2.0](https://github.com/TecharoHQ/thoth-proto/compare/v0.1.0...v0.2.0) (2025-05-19)


### Features

* **iptoasn:** support returning multiple prefixes ([9a89982](https://github.com/TecharoHQ/thoth-proto/commit/9a89982410d66d1b48c892c84f51a54cfa7ad432))

# [0.1.0](https://github.com/TecharoHQ/thoth-proto/compare/v0.0.1...v0.1.0) (2025-05-19)


### Features

* iptoasn service ([aa17222](https://github.com/TecharoHQ/thoth-proto/commit/aa172229ac6d476407c8268a13e9127eaf8c7dbe))
