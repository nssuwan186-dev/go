// Package yeet is a set of small helper functions useful for yeeting out scripts.
package yeet
