This archive contains some text files.
