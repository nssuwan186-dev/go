// Package text provides functionalities to manipulate texts.
package text
