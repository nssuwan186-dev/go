// Copyright The Prometheus Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package iscsi_test

import (
	"testing"

	"github.com/google/go-cmp/cmp"

	"github.com/prometheus/procfs/iscsi"
)

func TestGetStats(t *testing.T) {
	tests := []struct {
		stat *iscsi.Stats
	}{
		{
			stat: &iscsi.Stats{
				Name: "iqn.2003-01.org.linux-iscsi.osd1.x8664:sn.8888bbbbddd0",
				Tpgt: []iscsi.TPGT{
					{
						Name:     "tpgt_1",
						TpgtPath: "testdata/fixtures/sys/kernel/config/target/iscsi/iqn.2003-01.org.linux-iscsi.osd1.x8664:sn.8888bbbbddd0/tpgt_1",
						IsEnable: true,
						Luns: []iscsi.LUN{
							{
								Name:       "lun_0",
								LunPath:    "testdata/fixtures/sys/kernel/config/target/iscsi/iqn.2003-01.org.linux-iscsi.osd1.x8664:sn.8888bbbbddd0/tpgt_1/lun/lun_0",
								Backstore:  "rd_mcp",
								ObjectName: "ramdisk_lio_1G",
								TypeNumber: "119",
							},
						},
					},
				},
				RootPath: "testdata/fixtures/sys/kernel/config/target/iscsi",
			},
		},
		{
			stat: &iscsi.Stats{
				Name: "iqn.2003-01.org.linux-iscsi.osd1.x8664:sn.abcd1abcd2ab",
				Tpgt: []iscsi.TPGT{
					{
						Name:     "tpgt_1",
						TpgtPath: "testdata/fixtures/sys/kernel/config/target/iscsi/iqn.2003-01.org.linux-iscsi.osd1.x8664:sn.abcd1abcd2ab/tpgt_1",
						IsEnable: true,
						Luns: []iscsi.LUN{
							{
								Name:       "lun_0",
								LunPath:    "testdata/fixtures/sys/kernel/config/target/iscsi/iqn.2003-01.org.linux-iscsi.osd1.x8664:sn.abcd1abcd2ab/tpgt_1/lun/lun_0",
								Backstore:  "iblock",
								ObjectName: "block_lio_rbd1",
								TypeNumber: "0",
							},
						},
					},
				},
				RootPath: "testdata/fixtures/sys/kernel/config/target/iscsi",
			},
		},
		{
			stat: &iscsi.Stats{
				Name: "iqn.2016-11.org.linux-iscsi.igw.x86:dev.rbd0",
				Tpgt: []iscsi.TPGT{
					{
						Name:     "tpgt_1",
						TpgtPath: "testdata/fixtures/sys/kernel/config/target/iscsi/iqn.2016-11.org.linux-iscsi.igw.x86:dev.rbd0/tpgt_1",
						IsEnable: true,
						Luns: []iscsi.LUN{
							{
								Name:       "lun_0",
								LunPath:    "testdata/fixtures/sys/kernel/config/target/iscsi/iqn.2016-11.org.linux-iscsi.igw.x86:dev.rbd0/tpgt_1/lun/lun_0",
								Backstore:  "fileio",
								ObjectName: "file_lio_1G",
								TypeNumber: "1",
							},
						},
					},
				},
				RootPath: "testdata/fixtures/sys/kernel/config/target/iscsi",
			},
		},
		{
			stat: &iscsi.Stats{
				Name: "iqn.2016-11.org.linux-iscsi.igw.x86:sn.ramdemo",
				Tpgt: []iscsi.TPGT{
					{
						Name:     "tpgt_1",
						TpgtPath: "testdata/fixtures/sys/kernel/config/target/iscsi/iqn.2016-11.org.linux-iscsi.igw.x86:sn.ramdemo/tpgt_1",
						IsEnable: true,
						Luns: []iscsi.LUN{
							{
								Name:       "lun_0",
								LunPath:    "testdata/fixtures/sys/kernel/config/target/iscsi/iqn.2016-11.org.linux-iscsi.igw.x86:sn.ramdemo/tpgt_1/lun/lun_0",
								Backstore:  "rbd",
								ObjectName: "iscsi-images-demo",
								TypeNumber: "0",
							},
						},
					},
				},
				RootPath: "testdata/fixtures/sys/kernel/config/target/iscsi",
			},
		},
	}

	readTests := []struct {
		read  uint64
		write uint64
		iops  uint64
	}{
		{10325, 40325, 204950},
		{20095, 71235, 104950},
		{10195, 30195, 301950},
		{1504, 4733, 1234},
	}

	sysconfigfs, err := iscsi.NewFS("testdata/fixtures/sys", "testdata/fixtures/sys/kernel/config")
	if err != nil {
		t.Fatalf("failed to access xfs fs: %v", err)
	}
	sysfsStat, err := sysconfigfs.ISCSIStats()
	statSize := len(sysfsStat)
	if statSize != 4 {
		t.Errorf("fixtures size does not match %d", statSize)
	}
	if err != nil {
		t.Errorf("unexpected test fixtures")
	}

	for i, stat := range sysfsStat {
		want, have := tests[i].stat, stat
		if diff := cmp.Diff(want, have); diff != "" {
			t.Fatalf("unexpected iSCSI stats (-want +got):\n%s", diff)
		} else {
			readMB, writeMB, iops, err := iscsi.ReadWriteOPS(stat.RootPath+"/"+stat.Name,
				stat.Tpgt[0].Name, stat.Tpgt[0].Luns[0].Name)
			if err != nil {
				t.Errorf("unexpected iSCSI ReadWriteOPS path %s %s %s",
					stat.Name, stat.Tpgt[0].Name, stat.Tpgt[0].Luns[0].Name)
				t.Errorf("%v", err)
			}
			if diff := cmp.Diff(readTests[i].read, readMB); diff != "" {
				t.Fatalf("unexpected iSCSI read data (-want +got):\n%s", diff)
			}
			if diff := cmp.Diff(readTests[i].write, writeMB); diff != "" {
				t.Fatalf("unexpected iSCSI write data (-want +got):\n%s", diff)
			}
			if diff := cmp.Diff(readTests[i].iops, iops); diff != "" {
				t.Fatalf("unexpected iSCSI iops data (-want +got):\n%s", diff)
			}
			switch stat.Tpgt[0].Luns[0].Backstore {
			case "rd_mcp":
				haveRdmcp, err := sysconfigfs.GetRDMCPPath("119", "ramdisk_lio_1G")
				if err != nil {
					t.Errorf("fail rdmcp error %v", err)
				}
				// Name ObjectName
				wantRdmcp := &iscsi.RDMCP{"rd_mcp_" + stat.Tpgt[0].Luns[0].TypeNumber, stat.Tpgt[0].Luns[0].ObjectName}

				if diff := cmp.Diff(wantRdmcp, haveRdmcp); diff != "" {
					t.Fatalf("unexpected rdmcp data (-want +got):\n%s", diff)
				}
			case "iblock":
				haveIblock, err := sysconfigfs.GetIblockUdev("0", "block_lio_rbd1")
				if err != nil {
					t.Errorf("fail iblock error %v", err)
				}
				// Name Bnumber ObjectName Iblock
				wantIblock := &iscsi.IBLOCK{"iblock_" + stat.Tpgt[0].Luns[0].TypeNumber, stat.Tpgt[0].Luns[0].TypeNumber, stat.Tpgt[0].Luns[0].ObjectName, "/dev/rbd1"}
				if diff := cmp.Diff(wantIblock, haveIblock); diff != "" {
					t.Fatalf("unexpected iblock data (-want +got):\n%s", diff)
				}
			case "fileio":
				haveFileIO, err := sysconfigfs.GetFileioUdev("1", "file_lio_1G")
				if err != nil {
					t.Errorf("fail fileio error %v", err)
				}
				// Name, Fnumber, ObjectName, Filename
				wantFileIO := &iscsi.FILEIO{"fileio_" + stat.Tpgt[0].Luns[0].TypeNumber, stat.Tpgt[0].Luns[0].TypeNumber, "file_lio_1G", "/home/iscsi/file_back_1G"}
				if diff := cmp.Diff(wantFileIO, haveFileIO); diff != "" {
					t.Fatalf("unexpected fileio data (-want +got):\n%s", diff)
				}
			case "rbd":
				haveRBD, err := sysconfigfs.GetRBDMatch("0", "iscsi-images-demo")
				if err != nil {
					t.Errorf("fail rbd error %v", err)
				}
				// Name, Rnumber, Pool, Image
				wantRBD := &iscsi.RBD{"rbd_" + stat.Tpgt[0].Luns[0].TypeNumber, stat.Tpgt[0].Luns[0].TypeNumber, "iscsi-images", "demo"}
				if diff := cmp.Diff(wantRBD, haveRBD); diff != "" {
					t.Fatalf("unexpected fileio data (-want +got):\n%s", diff)
				}
			}
		}
	}
}
