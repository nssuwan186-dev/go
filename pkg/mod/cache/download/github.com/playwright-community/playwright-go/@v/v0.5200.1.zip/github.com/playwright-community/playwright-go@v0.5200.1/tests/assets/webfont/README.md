This icon font was generated:
- using SVG icons from https://github.com/primer/octicons
- bundling icons into webfonts using https://github.com/fontello/fontello
