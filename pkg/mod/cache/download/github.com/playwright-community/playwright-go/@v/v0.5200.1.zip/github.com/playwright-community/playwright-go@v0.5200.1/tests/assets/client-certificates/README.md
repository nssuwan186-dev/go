# Client Certificate test-certificates

Regenerate all certificates by running:

```
bash generate.sh
```
