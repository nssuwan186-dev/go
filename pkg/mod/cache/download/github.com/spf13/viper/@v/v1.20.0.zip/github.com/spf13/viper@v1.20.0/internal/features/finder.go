//go:build viper_finder

package features

const Finder = true
