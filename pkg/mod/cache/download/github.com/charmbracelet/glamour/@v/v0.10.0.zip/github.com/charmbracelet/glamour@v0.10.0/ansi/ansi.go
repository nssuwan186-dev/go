// Package ansi handle conversion of markdown to pretty ANSI output on the
// terminal.
package ansi
