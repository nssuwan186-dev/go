| Name | Role | Handle | Image |
| ---- | ---- | ------ | ----- |
| Andrey | Engineering | [@andreynering](https://github.com/andreynering) | ![](https://github.com/andreynering.png) |
| Ayman | Engineering | [@aymanbagabas](https://github.com/aymanbagabas) | ![](https://github.com/aymanbagabas.png) |
| Bash | Engineering | [@bashbunni](https://github.com/bashbunni) | ![](https://github.com/bashbunni.png) |
| Carlos | Engineering | [@caarlos0](https://github.com/caarlos0) | ![](https://github.com/caarlos0.png) |
| Christian | Product | [@meowgorithm](https://github.com/meowgorithm) | ![](https://github.com/meowgorithm.png) |
| Rapha | Intern | [@raphamorim](https://github.com/raphamorim) | ![](https://github.com/raphamorim.png) |
