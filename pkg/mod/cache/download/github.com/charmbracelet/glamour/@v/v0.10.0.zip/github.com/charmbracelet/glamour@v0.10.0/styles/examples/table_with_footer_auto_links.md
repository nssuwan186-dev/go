| Name | Role | Handle |
| ---- | ---- | ------ |
| Andrey | Engineering | https://github.com/andreynering |
| Ayman | Engineering | https://github.com/aymanbagabas |
| Bash | Engineering | https://github.com/bashbunni |
| Carlos | Engineering | https://github.com/caarlos0 |
| Christian | Product | https://github.com/meowgorithm |
| Rapha | Intern | https://github.com/raphamorim |
