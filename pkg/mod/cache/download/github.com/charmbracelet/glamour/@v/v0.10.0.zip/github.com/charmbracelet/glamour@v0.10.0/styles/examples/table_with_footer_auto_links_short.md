| Description          | Link                                                                            |
| -------------------- | ------------------------------------------------------------------------------- |
| Issue                | https://github.com/owner/repo/issue/123                                         |
| Issue                | https://github.com/owner/repo/issues/123                                        |
| Issue Comment        | https://github.com/owner/repo/issue/123#issuecomment-456                        |
| Issue Comment        | https://github.com/owner/repo/issues/123#issuecomment-456                       |
| Pull Request         | https://github.com/owner/repo/pull/123                                          |
| Pull Request         | https://github.com/owner/repo/pulls/123                                         |
| Pull Request Comment | https://github.com/owner/repo/pull/123#issuecomment-456                         |
| Pull Request Comment | https://github.com/owner/repo/pulls/123#issuecomment-456                        |
| Pull Request Comment | https://github.com/owner/repo/pull/123#discussion_r456                          |
| Pull Request Comment | https://github.com/owner/repo/pulls/123#discussion_r456                         |
| Pull Request Review  | https://github.com/owner/repo/pull/123#pullrequestreview-456                    |
| Pull Request Review  | https://github.com/owner/repo/pulls/123#pullrequestreview-456                   |
| Discussion           | https://github.com/owner/repo/discussions/123                                   |
| Discussion Comment   | https://github.com/owner/repo/discussions/123#discussioncomment-456             |
| Commit               | https://github.com/owner/repo/commit/abcdefghijklmnopqrsxyz                     |
| Commit               | https://github.com/owner/repo/commit/abcdefghijklmnopqrsxyz#diff-123            |
| Pull Request Commit  | https://github.com/owner/repo/pull/123/commits/abcdefghijklmnopqrsxyz           |
| Pull Request Commit  | https://github.com/owner/repo/pulls/123/commits/abcdefghijklmnopqrsxyz          |
| Pull Request Commit  | https://github.com/owner/repo/pull/123/commits/abcdefghijklmnopqrsxyz#diff-123  |
| Pull Request Commit  | https://github.com/owner/repo/pulls/123/commits/abcdefghijklmnopqrsxyz#diff-123 |
