| Name | Role | Handle | Image |
| ---- | ---- | ------ | ----- |
| Andrey | Engineering | [@andreynering](https://github.com/andreynering) | ![GitHub avatar](https://github.com/andreynering.png) |
| Ayman | Engineering | [@aymanbagabas](https://github.com/aymanbagabas) | ![GitHub avatar](https://github.com/aymanbagabas.png) |
| Bash | Engineering | [@bashbunni](https://github.com/bashbunni) | ![GitHub avatar](https://github.com/bashbunni.png) |
| Carlos | Engineering | [@caarlos0](https://github.com/caarlos0) | ![GitHub avatar](https://github.com/caarlos0.png) |
| Christian | Product | [@meowgorithm](https://github.com/meowgorithm) | ![GitHub avatar](https://github.com/meowgorithm.png) |
| Rapha | Intern | [@raphamorim](https://github.com/raphamorim) | ![GitHub avatar](https://github.com/raphamorim.png) |
