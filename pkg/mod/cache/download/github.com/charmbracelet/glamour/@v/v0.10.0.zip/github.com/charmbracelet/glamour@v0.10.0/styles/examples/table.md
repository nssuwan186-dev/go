| Label  | Value | URL              |
| ------ | ----- | ---------------- |
| First  | foo   | https://charm.sh |
| Second | bar   | https://charm.sh |
