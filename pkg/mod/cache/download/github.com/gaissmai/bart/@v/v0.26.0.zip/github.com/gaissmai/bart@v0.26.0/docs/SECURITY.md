# Security Policy

## Reporting a Vulnerability

You can report vulnerabilities privately via email: <mailto:karl.gaissmaier@uni-ulm.de>.
