package assemblyscript

const (
	AbortName = "abort"
	TraceName = "trace"
	SeedName  = "seed"
)
