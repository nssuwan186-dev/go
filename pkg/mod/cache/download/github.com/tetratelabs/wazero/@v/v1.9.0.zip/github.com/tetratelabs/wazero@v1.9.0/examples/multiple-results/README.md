## Multiple results example

This example shows how to return more than one result from WebAssembly or
Go-defined functions.
