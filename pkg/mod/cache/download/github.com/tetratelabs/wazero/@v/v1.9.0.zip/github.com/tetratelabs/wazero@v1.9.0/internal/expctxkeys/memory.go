package expctxkeys

// MemoryAllocatorKey is a context.Context key for the experimental memory allocator.
type MemoryAllocatorKey struct{}
