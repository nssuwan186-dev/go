## Concurrent Instantiation example

This example demonstrates how to instantiate multiple Wasm instances per Goroutine __concurrently__.

```bash
$  go run main.go
0
98
4
40
42
30
32
24
2
--snip--
```
