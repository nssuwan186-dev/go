// Package backend must be free of Wasm-specific concept. In other words,
// this package must not import internal/wasm package.
package backend
