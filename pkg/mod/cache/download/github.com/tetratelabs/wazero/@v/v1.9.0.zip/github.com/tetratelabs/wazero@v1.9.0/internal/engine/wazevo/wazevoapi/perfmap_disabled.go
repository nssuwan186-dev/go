//go:build !perfmap

package wazevoapi

const PerfMapEnabled = false
