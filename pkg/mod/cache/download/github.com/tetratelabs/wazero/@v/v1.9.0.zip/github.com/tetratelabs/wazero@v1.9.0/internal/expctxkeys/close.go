package expctxkeys

// CloseNotifierKey is a context.Context Value key. Its associated value should be a
// Notifier.
type CloseNotifierKey struct{}
