package gitconfig

const version = "0.2.1"
