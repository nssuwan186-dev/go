# plan9stats
A module for retrieving statistics of Plan 9

[![GoDev][godev-image]][godev-url]
[![Actions Status][actions-image]][actions-url]

[godev-image]: https://pkg.go.dev/badge/github.com/lufia/plan9stats
[godev-url]: https://pkg.go.dev/github.com/lufia/plan9stats
[actions-image]: https://github.com/lufia/plan9stats/workflows/Test/badge.svg?branch=main
[actions-url]: https://github.com/lufia/plan9stats/actions?workflow=Test
