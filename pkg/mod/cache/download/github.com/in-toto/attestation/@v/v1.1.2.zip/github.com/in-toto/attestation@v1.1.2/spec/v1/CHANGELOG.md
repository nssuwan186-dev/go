# Changelog

## v1.1

-   Clarified that subjects are assumed to be immutable and that it is
acceptable to use a non-cryptographic digest (though cryptographic
digests are still strongly recommended).

## v1

Initial release.
