# in-toto Governance

in-toto's
[governance](https://github.com/in-toto/community/blob/main/GOVERNANCE.md) and
[code of conduct](https://github.com/in-toto/community/blob/main/CODE-OF-CONDUCT.md)
are described in the [in-toto/community](https://github.com/in-toto/community)
repository.

## in-toto Attestation Framework Contributions

This implementation adheres to
[in-toto's contributing guidelines](https://github.com/in-toto/community/blob/main/CONTRIBUTING.md).
Pull requests must be submitted to the `main` branch where they undergo review
and automated testing.
