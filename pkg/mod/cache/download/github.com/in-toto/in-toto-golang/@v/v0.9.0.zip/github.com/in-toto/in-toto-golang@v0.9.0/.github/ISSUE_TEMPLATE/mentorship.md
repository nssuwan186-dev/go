---
name: Mentorship Request
about: Interested in getting involved, but want some guidance? Submit a mentorship request!
title: Mentorship request for <your-name>
labels: mentorship
assignees: ''

---

<!--
If you're new to the project, welcome!

In addition to filling out this mentorship request, consider joining the
#in-toto channel on the CNCF slack workspace and introducing yourself!
Link to sign up: https://slack.cncf.io/

-->

**About**
<!--Tell us a bit about yourself! How did you find the project?-->


**Skills**
<!--
Tell us a bit about your background: what skills you have, relevant prior
experience, etc. Don't copy-paste your entire resume -- this is not an
interview! We just need enough to get the ball rolling.
-->


**Interest areas**
<!--Are there any particular parts of the project you would like to contribute 
to?-->

