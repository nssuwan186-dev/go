## in-toto key

Key management commands

### Options

```
  -h, --help   help for key
```

### SEE ALSO

* [in-toto](in-toto.md)	 - Framework to secure integrity of software supply chains
* [in-toto key id](in-toto_key_id.md)	 - Output the key id for a given key
* [in-toto key layout](in-toto_key_layout.md)	 - Output the key layout for a given key in <KEYID>: <KEYOBJ> format

