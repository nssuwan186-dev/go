---
name: Feature Request
about: Do you miss a feature in in-toto?
title: <your feature request summary here>
labels: enhancement
assignees: ''

---

**Description of the feature request:**

