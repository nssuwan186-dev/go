## in-toto key layout

Output the key layout for a given key in <KEYID>: <KEYOBJ> format

### Synopsis

Output is a json formatted pubkey suitable for embedding in a layout file

```
in-toto key layout <file> [flags]
```

### Options

```
  -h, --help   help for layout
```

### SEE ALSO

* [in-toto key](in-toto_key.md)	 - Key management commands

