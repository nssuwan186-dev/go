## in-toto gendoc

Generate in-toto-golang's help docs

```
in-toto gendoc [flags]
```

### Options

```
  -d, --dir string   Path to directory in which to generate docs (default "doc")
  -h, --help         help for gendoc
```

### SEE ALSO

* [in-toto](in-toto.md)	 - Framework to secure integrity of software supply chains

