## in-toto key id

Output the key id for a given key

### Synopsis

Output the key id for a given key

```
in-toto key id <file> [flags]
```

### Options

```
  -h, --help   help for id
```

### SEE ALSO

* [in-toto key](in-toto_key.md)	 - Key management commands

