package main

import (
	"github.com/in-toto/in-toto-golang/cmd"
)

func main() {
	cmd.Execute()
}
