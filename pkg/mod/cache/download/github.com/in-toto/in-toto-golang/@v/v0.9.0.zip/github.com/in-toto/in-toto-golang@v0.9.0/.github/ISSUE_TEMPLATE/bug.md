---
name: Bug Report
about: Did you find a bug? Share it! :)
title: <your bug report summary here>
labels: bug
assignees: ''

---

**General information:**

* Version (tag or commit):
* Operating system (Linux/Mac/Windows):
* Go version:
* Go build flags (if any):


**Description of the bug:**


**Anything special you want to tell us?**

