# Release Notes v0.5.5

This release includes a go.mod file. Many thanks to
[M. J. Fromberger](https://github.com/creachadair) for providing the
fix. 
