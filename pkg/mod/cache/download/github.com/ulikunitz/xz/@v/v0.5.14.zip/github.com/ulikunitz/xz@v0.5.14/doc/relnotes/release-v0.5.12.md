# Release Notes v0.5.12

This release updates README.md and SECURITY.md to address questions regarding
the supply chain attack against the original xz implementation.

Thanks github user @rfay for the raising the issue.
