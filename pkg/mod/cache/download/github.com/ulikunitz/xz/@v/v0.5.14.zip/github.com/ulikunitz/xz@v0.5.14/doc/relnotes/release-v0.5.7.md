# Release Notes v0.5.7

This release fixes issue #27 "Checksum None is valid" by supporting the
check-ID None.

Many thanks to [blacktop](https://github.com/blacktop) for reporting the
bug.
