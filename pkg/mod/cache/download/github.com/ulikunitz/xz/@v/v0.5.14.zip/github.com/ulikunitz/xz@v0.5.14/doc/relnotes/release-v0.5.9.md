# Release Notes v0.5.9

This release fixes:

    - all staticcheck issues in the public repositories.
    - fixes wrong const type definitions; thanks Matt LaPlante
    - fixes a typo; Michael Vetter
    - adds a SECURITY.md file
