# Release Notes v0.5.13

This release adds package xio to handle situations with multiple WriteClosers
that were pointed out by @kodawah in issue #61.