# SECURITY

It's somewhat unlikely that tcell is in a security sensitive path,
but we do take security seriously.

## Vulnerabilityu Response

If you report a vulnerability, we will respond within 2 business days.

## Report a Vulnerability

If you wish to report a vulnerability found in tcell, simply send a message
to garrett@damore.org.  You may also reach us on our discord channel -
https://discord.gg/urTTxDN - a private message to `gdamore` on that channel
may be submitted instead of mail.
