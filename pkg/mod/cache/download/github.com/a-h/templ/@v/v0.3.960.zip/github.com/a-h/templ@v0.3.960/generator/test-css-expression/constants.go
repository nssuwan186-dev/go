package testcssexpression

const red = "#ff0000"
