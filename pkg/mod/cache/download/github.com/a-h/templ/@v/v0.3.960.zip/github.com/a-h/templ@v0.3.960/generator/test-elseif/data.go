package elseif

type data struct {
}

func (d data) IsTrue() bool {
	return false
}
