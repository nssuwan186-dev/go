package runtime

import "strings"

// GetBuilder returns a strings.Builder.
func GetBuilder() (sb strings.Builder) {
	return sb
}
