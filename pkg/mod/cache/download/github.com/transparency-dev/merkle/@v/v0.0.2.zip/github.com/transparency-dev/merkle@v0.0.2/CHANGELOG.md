# MERKLE changelog

## HEAD

## v0.0.2
 * Fuzzing support
 * Dependency updates, notably to go1.19

## v0.0.1
Initial release
