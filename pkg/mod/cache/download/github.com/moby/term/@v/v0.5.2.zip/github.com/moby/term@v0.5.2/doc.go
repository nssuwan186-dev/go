// Package term provides structures and helper functions to work with
// terminal (state, sizes).
package term
