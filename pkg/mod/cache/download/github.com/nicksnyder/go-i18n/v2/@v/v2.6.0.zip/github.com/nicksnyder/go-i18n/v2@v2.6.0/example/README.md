# Example

This directory contains an example project that uses go-i18n.

```
go run main.go
```

Then open http://localhost:8080 in your web browser.

You can customize the template data and locale via query parameters like this:
http://localhost:8080/?name=Nick&unreadEmailCount=2
http://localhost:8080/?name=Nick&unreadEmailCount=2&lang=es
